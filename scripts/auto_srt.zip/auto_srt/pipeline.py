import json
import sys
import re
from pathlib import Path
from transformers import pipeline

# -----------------------------
# Utilities
# -----------------------------

def seconds_to_srt(ts: float) -> str:
    h = int(ts // 3600)
    m = int((ts % 3600) // 60)
    s = int(ts % 60)
    ms = int(round((ts - int(ts)) * 1000))
    if ms == 1000:
        s += 1
        ms = 0
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def clean_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([,.!?])", r"\1", text)
    return text

def sentence_boundary(text: str) -> bool:
    return bool(re.search(r"[.!?]\s*$", text))

# -----------------------------
# Chunking Logic
# -----------------------------

def build_blocks(segments):
    blocks = []
    current = []

    def duration(block):
        return block[-1]["timestamp"][1] - block[0]["timestamp"][0]

    for seg in segments:
        if not current:
            current.append(seg)
            continue

        current.append(seg)
        text = clean_text(" ".join(s["text"] for s in current))

        if (
            sentence_boundary(text)
            and duration(current) >= 8
            or duration(current) >= 22
        ):
            blocks.append(current)
            current = []

    if current:
        blocks.append(current)

    return blocks

# -----------------------------
# Keyword Generator
# -----------------------------

def generate_keywords(text):
    text = text.lower()
    keywords = []

    def add(*items):
        for i in items:
            if i not in keywords:
                keywords.append(i)

    if "oil" in text or "tanker" in text:
        add(
            "oil tanker at sea",
            "cargo ship ocean",
            "global shipping trade",
            "energy transportation"
        )

    if "military" in text or "jets" in text:
        add(
            "fighter jets in sky",
            "military aircraft formation",
            "air force patrol"
        )

    if "economy" in text or "inflation" in text:
        add(
            "economic uncertainty",
            "financial charts abstract",
            "cost of living visuals"
        )

    if "government" in text or "policy" in text:
        add(
            "government buildings exterior",
            "political decision making",
            "international relations visuals"
        )

    if not keywords:
        add(
            "world news visuals",
            "serious documentary b-roll",
            "global affairs imagery"
        )

    return keywords[:5]

# -----------------------------
# Main Pipeline
# -----------------------------

def main():
    audio_path = Path(sys.argv[1]).resolve()
    base = audio_path.with_suffix("")

    print("Loading transcription model...")
    asr = pipeline(
        "automatic-speech-recognition",
        model="openai/whisper-large-v3",
        return_timestamps=True
    )

    print("Transcribing audio...")
    result = asr(str(audio_path))

    segments = [
        {
            "timestamp": [chunk["timestamp"][0], chunk["timestamp"][1]],
            "text": chunk["text"]
        }
        for chunk in result["chunks"]
    ]

    # Save raw JSON
    json_path = base.with_suffix(".json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(segments, f, indent=2)

    print("Building SRT blocks...")
    blocks = build_blocks(segments)

    # Write SRT
    srt_path = base.with_suffix(".srt")
    with open(srt_path, "w", encoding="utf-8") as f:
        for i, block in enumerate(blocks, 1):
            start = block[0]["timestamp"][0]
            end = block[-1]["timestamp"][1]
            text = clean_text(" ".join(s["text"] for s in block))

            f.write(f"{i}\n")
            f.write(f"{seconds_to_srt(start)} --> {seconds_to_srt(end)}\n")
            f.write(text + "\n\n")

    # Write keyword prompts
    keywords_path = base.parent / f"{base.name}_keywords.txt"
    with open(keywords_path, "w", encoding="utf-8") as f:
        for i, block in enumerate(blocks, 1):
            text = clean_text(" ".join(s["text"] for s in block))
            kws = generate_keywords(text)

            f.write(f"[Block {i}]\n")
            for k in kws:
                f.write(k + "\n")
            f.write("\n")

    print("Done.")
    print(f"Created:\n- {json_path.name}\n- {srt_path.name}\n- {keywords_path.name}")

if __name__ == "__main__":
    main()
